//: Playground - noun: a place where people can play

import UIKit

var v1 = "Esto es Swift"
let c1=4
var cadena: String = String()
cadena = "Hola mundo" + v1
print("el contenido es: \(cadena)")
print("el valor de constante es: \(c1)")
